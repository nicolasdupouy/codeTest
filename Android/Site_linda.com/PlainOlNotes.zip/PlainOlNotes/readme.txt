This project requires ActionBarSherlock, an open source library
Download from: http://actionbarsherlock.com